# -*- coding: utf-8 -*-
"""
Created on Fri Jun 12 16:23:07 2020

@author: Tulasi
"""

let content=document.getElementById('div-content');
content.innerHTML="";
content.innerHTML="Im from java script";
